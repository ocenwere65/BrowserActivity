package com.example.browseractivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ShareActionProvider;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class BrowserActivity extends AppCompatActivity implements PageControlFragment.PageControlInterface, PageViewerFragment.PageViewerInterface, BrowserControlFragment.BrowserControlInterface, PagerFragment.PagerInterface, PageListFragment.PageListInterface {

    FragmentManager fm;

    private final String PAGES_KEY = "pages";
    private final int REQUEST_CODE = 111;

    private ShareActionProvider shareActionProvider;

    PageControlFragment pageControlFragment;
    BrowserControlFragment browserControlFragment;
    PageListFragment pageListFragment;
    PagerFragment pagerFragment;
    BookmarkListFragment bookmarkListFragment;

    PageViewerFragment pageViewerFragment;

    ArrayList<PageViewerFragment> pages;
    ArrayList<String> marks;
    ArrayList<String> urls;

    boolean listMode;
    boolean bookListMode;

    Intent secondActivityIntent;

    ArrayList<Integer> integer;

    int counter = 0;
    boolean checkDel = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null)
            pages = (ArrayList) savedInstanceState.getSerializable(PAGES_KEY);
        else
            pages = new ArrayList<>();

        marks = new ArrayList<>();
        urls = new ArrayList<>();

        fm = getSupportFragmentManager();

        listMode = findViewById(R.id.page_list) != null;
        bookListMode = findViewById(R.id.bookmark_list) != null;

        Fragment tmpFragment;



        // If BrowserFragment already added (activity restarted) then hold reference
        // otherwise add new fragment. Only one instance of fragment is ever present
        if ((tmpFragment = fm.findFragmentById(R.id.browser_control)) instanceof BrowserControlFragment)
            browserControlFragment = (BrowserControlFragment) tmpFragment;
        else {
            browserControlFragment = new BrowserControlFragment();
            fm.beginTransaction()
                    .add(R.id.browser_control, browserControlFragment)
                    .commit();
        }

        // If PagerFragment already added (activity restarted) then hold reference
        // otherwise add new fragment. Only one instance of fragment is ever present
        if ((tmpFragment = fm.findFragmentById(R.id.page_viewer)) instanceof PagerFragment)
            pagerFragment = (PagerFragment) tmpFragment;
        else {
            pagerFragment = PagerFragment.newInstance(pages, new PageViewerFragment());
            fm.beginTransaction()
                    .add(R.id.page_viewer, pagerFragment)
                    .commit();
        }


        // If fragment already added (activity restarted) then hold reference
        // otherwise add new fragment IF container available. Only one instance
        // of fragment is ever present
        if (listMode) {
            if ((tmpFragment = fm.findFragmentById(R.id.page_list)) instanceof PageListFragment)
                pageListFragment = (PageListFragment) tmpFragment;
            else {
                pageListFragment = PageListFragment.newInstance(pages);
                fm.beginTransaction()
                        .add(R.id.page_list, pageListFragment)
                        .commit();
            }
        }

        if(bookListMode) {
            // If BookmarkListFragment already added (activity restarted) then hold reference
            // otherwise add new fragment. Only one instance of fragment is ever present
            if ((tmpFragment = fm.findFragmentById(R.id.bookmark_list)) instanceof BookmarkListFragment)
                bookmarkListFragment = (BookmarkListFragment) tmpFragment;
            else {
                bookmarkListFragment = new BookmarkListFragment();
                fm.beginTransaction()
                        .add(R.id.bookmark_list, bookmarkListFragment)
                        .commit();
            }
        }

        // If PageControlFragment already added (activity restarted) then hold reference
        // otherwise add new fragment. Only one instance of fragment is ever present
        if ((tmpFragment = fm.findFragmentById(R.id.page_control)) instanceof PageControlFragment)
            pageControlFragment = (PageControlFragment) tmpFragment;
        else {
            pageControlFragment = new PageControlFragment();
            fm.beginTransaction()
                    .add(R.id.page_control, pageControlFragment)
                    .commit();
        }

        secondActivityIntent = new Intent(BrowserActivity.this, BookmarksActivity.class);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        MenuItem item = menu.findItem(R.id.shareButton);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.shareButton:
                Intent shareIntent = new Intent(android.content.Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                String shareBody = "";
                if(pages.size() > 0)
                    shareBody = pagerFragment.getCurrentUrl();
                shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,"Subject");
                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(shareIntent, "Share via"));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Clear the url bar and activity title
     */
    private void clearIdentifiers() {
        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle("");
        pageControlFragment.updateUrl("");
    }

    // Notify all observers of collections
    private void notifyWebsitesChanged() {
        pagerFragment.notifyWebsitesChanged();
        if (listMode) {
            pageListFragment.notifyWebsitesChanged();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save list of open pages for activity restart
        outState.putSerializable(PAGES_KEY, pages);
    }

    /**
     * Update WebPage whenever PageControlFragment sends new Url
     * Create new page first if none exists
     * Alternatively, you can create an empty page when the activity first loads
     *
     * @param url to load
     */
    @Override
    public void go(String url) {
        if (pages.size() > 0) {
            pagerFragment.go(url);
        } else {
            pages.add(PageViewerFragment.newInstance(url));
            notifyWebsitesChanged();
            pagerFragment.showPage(pages.size() - 1);
        }
    }

    /**
     * Go back to previous page when user presses Back in PageControlFragment
     */
    @Override
    public void back() {
        pagerFragment.back();
    }

    /**
     * Go forward to next page when user presses Forward in PageControlFragment
     */
    @Override
    public void forward() {
        pagerFragment.forward();
    }

    /**
     * Update displayed Url in PageControlFragment when Webpage Url changes
     * only if it is the currently displayed page, and not another page
     *
     * @param url to display
     */
    @Override
    public void updateUrl(String url) {
        if (url != null && url.equals(pagerFragment.getCurrentUrl())) {
            pageControlFragment.updateUrl(url);

            // Update the ListView in the PageListFragment - results in updated titles
            notifyWebsitesChanged();
        }
    }

    /**
     * Update displayed page title in activity when Webpage Url changes
     * only if it is the currently displayed page, and not another page
     *
     * @param title to display
     */
    @Override
    public void updateTitle(String title) {
        if (title != null && title.equals(pagerFragment.getCurrentTitle()) && getSupportActionBar() != null)
            getSupportActionBar().setTitle(title);

        // Results in the ListView in PageListFragment being updated
        notifyWebsitesChanged();
    }

    /**
     * Add a new page/fragment to the list and display it
     */
    @Override
    public void newPage() {
        // Add page to list
        pages.add(new PageViewerFragment());
        // Update all necessary views
        notifyWebsitesChanged();
        // Display the newly created page
        pagerFragment.showPage(pages.size() - 1);
        // Clear the displayed URL in PageControlFragment and title in the activity
        clearIdentifiers();
    }

    @Override
    public void savePage() {
        String s = "", url = "";
        if(pages.size() > 0)
            s = pagerFragment.getCurrentTitle();
        if(pages.size() > 0)
            url = pagerFragment.getCurrentUrl();
        marks.add(s);
        urls.add(url);
        Toast.makeText(this, "Bookmark Saved", Toast.LENGTH_LONG).show();
    }

    @Override
    public void listBookMarks() {
        if(counter > 0 && checkDel){
            for(int j = 0; j < integer.size(); j++){
                marks.remove((int) integer.get(j));
                urls.remove((int) integer.get(j));
            }
        }

        secondActivityIntent.putStringArrayListExtra("STRINGS_I_NEED", marks);
        secondActivityIntent.putStringArrayListExtra("URLS_I_NEED", urls);
        startActivityForResult(secondActivityIntent, REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String str = "";
        boolean hasBackPressed = false;
        boolean ifDelete = false;

        if(resultCode == Activity.RESULT_OK){
            hasBackPressed = data.getBooleanExtra("hasBackPressed", false);
            ifDelete = data.getBooleanExtra("ifDelete", false);
        }
        if(data.getExtras() != null && !hasBackPressed) {
            str = (String) data.getExtras().getString("url");
            pagerFragment.go(str);
        }
        if(hasBackPressed && ifDelete){
            counter++; checkDel = ifDelete;
            integer = data.getIntegerArrayListExtra("indexes_i_need");
            for(int j = 0; j < integer.size(); j++){
                marks.remove(integer.get(j));
                urls.remove(integer.get(j));
            }
        }
    }

    /**
     * Display requested page in the PagerFragment
     *
     * @param position of page to display
     */
    @Override
    public void pageSelected(int position) {
        pagerFragment.showPage(position);
    }

}