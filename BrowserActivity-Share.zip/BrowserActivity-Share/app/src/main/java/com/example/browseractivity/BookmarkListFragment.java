package com.example.browseractivity;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class BookmarkListFragment extends Fragment {

    private BookmarkListInterface bookmarkListActivity;

    private ListView listView;

    View view;

    ArrayList<String> titles;

    public BookmarkListFragment() {}

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof BookmarkListInterface) {
            bookmarkListActivity = (BookmarkListInterface) context;
        } else {
            throw new RuntimeException("You must implement BookmarkListInterface before attaching this fragment");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_bookmark_list, container, false);
        listView = view.findViewById(R.id.listMarks);

        titles = new ArrayList<>();
        listView.setAdapter(new BookMarkAdapter(getActivity(), titles));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                bookmarkListActivity.bookmarkSelected(position);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                bookmarkListActivity.getItem(position);
                return true;
            }
        });

        bookmarkListActivity.placeItem();

        return view;
    }

    interface BookmarkListInterface {
        void placeItem();
        void getItem(int position);
        void bookmarkSelected(int position);
    }

    public void addItem(final ArrayList<String> s){
        int counter = 0;
        while (counter < s.size()){
            titles.add(s.get(counter));
            counter++;
        }
    }

    public void deleteItem(int i){
        titles.remove(i);
        notifyBookmarksChanged();
    }

    /**
     * Update the list of websites when a new page added or changed
     */
    public void notifyBookmarksChanged() {
        if (listView != null)
            ((BaseAdapter) listView.getAdapter()).notifyDataSetChanged();
    }

    public ArrayList<String> saveMarks(){
        return titles;
    }
}
