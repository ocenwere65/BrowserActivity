package com.example.browseractivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class BookmarksActivity extends AppCompatActivity implements BookmarkListFragment.BookmarkListInterface {

    FragmentManager fm;

    private final String MARKS_KEY = "marks";
    private final String URLS_KEY = "urls";

    BookmarkListFragment bookmarkListFragment;

    boolean bookListMode;
    boolean ifDelete = false;

    ArrayList<String> marks;
    ArrayList<String> urls;
    ArrayList<Integer> removedInts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarks);

        Intent startIntent = getIntent();

        if (savedInstanceState != null) {
            marks = (ArrayList) savedInstanceState.getSerializable(MARKS_KEY);
            urls = (ArrayList) savedInstanceState.getSerializable(URLS_KEY);
        }else {
            if(startIntent.getExtras() != null) {
                marks = (ArrayList<String>) startIntent.getExtras().get("STRINGS_I_NEED");
                urls = (ArrayList<String>) startIntent.getExtras().get("URLS_I_NEED");
            }
        }

        removedInts = new ArrayList<>();

        fm = getSupportFragmentManager();

        bookListMode = findViewById(R.id.bookmark_list) != null;

        Fragment tmpFragment;

        if(bookListMode && marks.size() > 0) {
            // If BookmarkListFragment already added (activity restarted) then hold reference
            // otherwise add new fragment. Only one instance of fragment is ever present
            if ((tmpFragment = fm.findFragmentById(R.id.bookmark_list)) instanceof BookmarkListFragment)
                bookmarkListFragment = (BookmarkListFragment) tmpFragment;
            else {
                bookmarkListFragment = new BookmarkListFragment();
                fm.beginTransaction()
                        .add(R.id.bookmark_list, bookmarkListFragment)
                        .commit();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save list of open pages for activity restart
        outState.putSerializable(MARKS_KEY, marks);
        outState.putSerializable(URLS_KEY, urls);
    }

    @Override
    public void placeItem() {
        if(marks.size() > 0)
            bookmarkListFragment.addItem(marks);
    }

    @Override
    public void getItem(final int i) {
        removedInts.add(i);
        if(marks.size() > 0){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Are you sure you want to delete bookmark?");

            builder.setCancelable(true);

            builder.setPositiveButton(
                    "Yes",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            marks.remove(i);
                            bookmarkListFragment.deleteItem(i);
                            bookmarkListFragment.notifyBookmarksChanged();
                            ifDelete = true;
                        }
                    });

            builder.setNegativeButton(
                    "No",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            ifDelete = false;
                        }
                    });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    @Override
    public void bookmarkSelected(int position) {
        String url = urls.get(position);
        Intent i = new Intent();
        i.putExtra("url", url);
        setResult(Activity.RESULT_OK, i);
        finish();
    }

    @Override
    public void onBackPressed() {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("hasBackPressed",true);
        returnIntent.putExtra("ifDelete",ifDelete);
        returnIntent.putIntegerArrayListExtra("indexes_i_need", removedInts);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}
